# Coffo Website
Coffo Website is used to check the posts from blog section and to buy the coffee in the shop through location
### Task-1: "Landing Page Creation"
### Software Tool Used: Visual Studio
### Languages Used: HTML, CSS, JS
### Library & Plugins:
Bootstrap 4
jQuery
Favicon
Google Fonts
### Key Features:
Bootstrap 4
HTML5 & CSS3
Gallery
Header Slider
Top Navigation Bar
Search filter
Hero header
Hero image
Burger Menu
Blog Section
Burger menu
100% Responsive
Testimonial Carousel
Call-to-action Buttons
On-hover Effects
Contact Form UI
Geolocation
Multipage Design
Font Awesome Icon Font
Social Media Links & Icons
Newsletter Subscription Form UI
### Live Preview: https://2200032698.github.io/Octanet_June_Task1/
